import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { FormDetails } from './SystemTest/SystemTest.Model';

@Injectable({
    providedIn: 'root'
})
export class HelperService {
    //URL for CRUD operations
    FormDetailsUrl = "/api/fromDetails";
    //Create constructor to get Http instance
    constructor(private http: HttpClient) { }
    //Fetch all FormDetailss
    getAllFormData(): Observable<FormDetails[]> {
        return this.http.get<FormDetails[]>(this.FormDetailsUrl).pipe(
            tap(FormDetails => console.log("Number of FormDetails: " + FormDetails.length)),
            catchError(this.handleError)
        );
    }
    //Create FormDetail
    createArticle(FormData: FormDetails): Observable<number> {
        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        return this.http.post<FormDetails>(this.FormDetailsUrl + "/" , FormData, {
            headers: httpHeaders,
            observe: 'response'
        }
        ).pipe(
            map(res => res.status),
            catchError(this.handleError)
        );
    }
    //Fetch FormData by id
    getFormDetailById(FormDataId: string): Observable<FormDetails> {
        return this.http.get<FormDetails>(this.FormDetailsUrl + "/" ).pipe(
            tap(FormData => console.log(FormDetails)),
            catchError(this.handleError)
        );
    }
    //Update FormData
    updateFormDetail(FormData: FormDetails): Observable<number> {
        let httpHeaders = new HttpHeaders({
            'Content-Type': 'application/json'
        });
        return this.http.put<FormDetails>(this.FormDetailsUrl + "/", FormData, {
            headers: httpHeaders,
            observe: 'response'
        }
        ).pipe(
            map(res => res.status),
            catchError(this.handleError)
        );
    }
    //Delete FormData	
    deleteFormDetailById(FormDataId: string): Observable<number> {
        return this.http.delete<number>(this.FormDetailsUrl + "/" + FormDataId).pipe(
            tap(status => console.log("status: " + status)),
            catchError(this.handleError)
        );
    }
    private handleError(error: any) {
        console.error(error);
        return throwError(error);
    }
}