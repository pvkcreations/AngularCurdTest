
export class FormDetails {
    FirstName:String=null;
    LastName:String=null;
    EmailId:String=null;
    ContactNumber:String=null;
    DateOfBirth:any=null;
    id:any=null;
} 