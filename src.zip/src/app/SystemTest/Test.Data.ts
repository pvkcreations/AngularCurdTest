
import { InMemoryDbService } from 'angular-in-memory-web-api';

export class TestData implements InMemoryDbService {
  createDb() {
    let FromDetails = [
        {id:1,FirstName:"Vamsi",LastName:"Krishna",EmailId:'vamsi.k@gmail.com',ContactNumber:"9999999999",DateOfBirth:"06-07-1940" },

    ];
    return { fromDetails: FromDetails };
  }
} 