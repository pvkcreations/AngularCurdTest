import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HelperService } from '../Helper.service';

@Component({
  selector: 'app-SystemTest',
  templateUrl: './SystemTest.component.html',
  styleUrls: ['./systemTest.component.css']

})
export class SystemTestComponent implements OnInit {

  public SystemTestform: FormGroup;
  public DetailsUpdate: any = false;
  processValidation = false;
  statusCode: number;
	requestProcessing = false;
	FormDataToUpdate = null;
  FormData:any=[];
  constructor( private FB:FormBuilder,private _help:HelperService) { }

  ngOnInit() {
    this.getAllFormData();
    this.Createform();
  }

   Createform() {
    this.SystemTestform=this.FB.group({
      FirstName:new FormControl('',Validators.required),
      LastName:new FormControl('',Validators.required),
      EmailId:new FormControl('',Validators.required),
      ContactNumber:new FormControl('',Validators.required),
      DateOfBirth:new FormControl('',Validators.required),
      
    })
  }

 
   getAllFormData() {
		this._help.getAllFormData()
			.subscribe(
				data => this.FormData = data,
				errorCode => this.statusCode = errorCode);
	}
	//Handle create and update formData
	onSystemTestSubmit() {
		this.processValidation = true;
		if (this.SystemTestform.invalid) {
			return; //Validation failed, exit from method.
		}
		//Form is valid, now perform create or update
		this.preProcessConfigurations();
		let CreateData = this.SystemTestform.value;
		if (this.FormDataToUpdate === null) {
			//Generate FormData id then create CreateData
			this._help.getAllFormData()
				.subscribe(formData => {
					//Generate CreateData id (logic is for demo)	 
					let maxIndex = formData.length - 1;
					let CreateDataWithMaxIndex = formData[maxIndex];
					let CreateDataId = CreateDataWithMaxIndex.id + 1;
					CreateData.id = CreateDataId;

					//Create
					this._help.createArticle(CreateData)
						.subscribe(statusCode => {
							//Expecting success code 201 from server
							this.statusCode = statusCode;
							this.getAllFormData();
							this.backToCreateForm();
						},
							errorCode => this.statusCode = errorCode
						);
				});
		} else {
			//Handle update CreateData
			CreateData.id = this.FormDataToUpdate;
			this._help.updateFormDetail(CreateData)
				.subscribe(statusCode => {
					this.statusCode = 200;
					this.getAllFormData();
					this.backToCreateForm();
				},
					errorCode => this.statusCode = errorCode);
		}
    this.DetailsUpdate=CreateData.id;
	}
	//Load CreateData by id to edit
	FormDataToEdit(event,FormDetails) {
		this.preProcessConfigurations();
		this._help.getFormDetailById(FormDetails)
			.subscribe(CreateData => {
				this.FormDataToUpdate = FormDetails.id;
				this.SystemTestform.setValue({ FirstName: FormDetails.FirstName, LastName: FormDetails.LastName,EmailId:FormDetails.EmailId,ContactNumber:FormDetails.ContactNumber,DateOfBirth:FormDetails.DateOfBirth });
				this.processValidation = true;
				this.requestProcessing = false;
        this.DetailsUpdate=FormDetails.id;
			},
				errorCode => this.statusCode = errorCode);
	}
	//Delete CreateData
	deleteFormData(event,formDataID) {
		this.preProcessConfigurations();
		this._help.deleteFormDetailById(formDataID.id)
			.subscribe(successCode => {
				this.statusCode = 204;
				this.getAllFormData();
				this.backToCreateForm();
			},
				errorCode => this.statusCode = errorCode);
	}
	//Perform preliminary processing configurations
	preProcessConfigurations() {
		this.statusCode = null;
		this.requestProcessing = true;
	}
	//Go back from update to create
  backToCreateForm(){
		this.FormDataToUpdate = null;
		this.SystemTestform.reset();
		this.processValidation = false;
    this.DetailsUpdate=null;
	}
} 
