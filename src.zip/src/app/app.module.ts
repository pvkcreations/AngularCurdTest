import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {  HttpClientModule } from '@angular/common/http';
import { SystemTestComponent } from './SystemTest/SystemTest.component';
import { TestData } from './SystemTest/Test.Data';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { HelperService } from './Helper.service';


@NgModule({
  declarations: [
    AppComponent,
    SystemTestComponent,
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule,ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,InMemoryWebApiModule.forRoot(TestData)
  ],
  providers: [HelperService],
  bootstrap: [AppComponent]
})
export class AppModule { }
